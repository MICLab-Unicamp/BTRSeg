import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

found = setuptools.find_packages()
print(f"Found these packages to add: {found}")

setuptools.setup(
    name="DLPT",
    version="0.0.1",
    author="Diedre Carmo",
    author_email="diedre@dca.fee.unicamp.br",
    description="DLPT",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    packages=found,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=['setuptools', 'numpy', 'scipy', 'scikit-learn', 'scikit-image', 'nibabel', 'pandas', 'mlflow', 'tqdm',
                      'matplotlib', 'opencv-python', 'sparse', 'torch', 'pytorch-lightning']
)
