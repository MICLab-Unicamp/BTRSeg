'''
Using DICE as a Loss
'''
import torch
import numpy as np

from DLPT.metrics.segmentation import vol_dice, batch_dice
from DLPT.loss import Loss


class DICELoss(Loss):
    '''
    Calculates DICE Loss
    Dont use with multiple targets. Use GDL.
    '''
    def __init__(self, volumetric=False, negative_loss=False, per_channel=False):
        self.name = "DICE Loss"
        super(DICELoss, self).__init__()
        self.volumetric = volumetric
        self.negative_loss = negative_loss
        self.per_channel = per_channel

        print(f"DICE Loss initialized with volumetric={volumetric}, negative? {negative_loss}, per_channel {per_channel}")

    def __call__(self, probs, targets):
        '''
        probs: output of last convolution, sigmoided or not (use apply_sigmoid=True if not)
        targets: binary target mask
        '''
        p_min = probs.min()
        p_max = probs.max()
        assert p_max <= 1.0 and p_min >= 0.0, "FATAL ERROR: DICE loss input not bounded! Did you apply sigmoid?"

        score = 0

        if self.per_channel:
            assert len(targets.shape) >= 4, ("less than 4 dimensions makes no sense with multi channel in a batch of 2D or 3D"
                                             "volumes")
            nchannels = targets.shape[1]
            if self.volumetric:
                score = torch.stack([vol_dice(probs[:, c], targets[:, c]) for c in range(nchannels)]).mean()
            else:
                score = torch.stack([batch_dice(probs[:, c], targets[:, c]) for c in range(nchannels)]).mean()
        else:
            if self.volumetric:
                score = vol_dice(probs, targets)
            else:
                score = batch_dice(probs, targets)

        if self.negative_loss:
            loss = -score
        else:
            loss = 1 - score

        return loss


class BalancedMultiChannelDICELoss(Loss):
    '''
    Specific case of DICE loss with multichannel softmax input instead of sigmoid
    Balance works by multiplying the loss value by the MSE of DICE scores per channel, multiplied by alpha.
    '''
    def __init__(self, max_ncalls, volumetric, init_weights=[1, 0]):
        '''
        volumetric: true if input Tensors will be 5D (B, C, X, Y, Z) False if 4D (B, C, X, Y)
        alpha: parameter to control the weight of balancing factor.
        '''
        self.name = "BalancedMultiChannelDICELoss"
        super().__init__()
        self.volumetric = volumetric
        self.init_weights = np.array(init_weights)
        self.max_ncalls = max_ncalls

        assert np.isclose(self.weights.sum(), 1.0)
        increment_module = abs(self.weights[0] - self.weights[1])/self.max_ncalls
        argmax = self.weights.argmax()
        self.increment = np.array([increment_module, increment_module])
        self.increment[argmax] = -1*self.increment[argmax]

        print(f"Balanced MultiChannel DICELoss initialized with {locals()}")

    def __call__(self, probs, targets):
        '''
        probs: output of last convolution, sigmoided or not (use apply_sigmoid=True if not)
        targets: binary target mask
        '''
        dice_weight, balance_weight = self.weights

        p_min = probs.min()
        p_max = probs.max()
        assert p_max <= 1.0 and p_min >= 0.0, "FATAL ERROR: DICE loss input not bounded! Did you apply sigmoid?"

        assert len(targets.shape) >= 4, ("less than 4 dimensions makes no sense with multi channel in a batch of 2D or 3D"
                                         "volumes")
        nchannels = targets.shape[1]
        if self.volumetric:
            dices = torch.stack([vol_dice(probs[:, c], targets[:, c]) for c in range(nchannels)])
        else:
            dices = torch.stack([batch_dice(probs[:, c], targets[:, c]) for c in range(nchannels)])

        # Inneficient implementation, however size of dices is [B, C], small.
        dists = torch.zeros_like(dices)
        for nb, sample_score in enumerate(dices):
            for channel_score in dices:
                dists[nb] += (sample_score - channel_score).abs()

        loss = dice_weight*(1 - dices.mean()) + balance_weight*dists.mean()  # optimal results mean lower distances and higher dice (scores)

        return loss

    def increment_weights(self):
        pre_increment = self.weights
        self.weights = self.weights + self.increment
        print(f"Balanced DICE weights: {pre_increment} -> {self.weights}")

    def reset_weights(self):
        print("Balanced DICE weights reset.")
        self.weights = self.init_weights
