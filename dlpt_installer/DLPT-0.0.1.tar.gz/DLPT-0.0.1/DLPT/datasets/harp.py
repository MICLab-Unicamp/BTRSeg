'''
Implementation of the HarP dataset
'''
import os
import glob
import logging
from os.path import join as add_path

import numpy as np
import nibabel as nib
import torch
from datasets import Dataset
from tqdm import tqdm
import multiprocessing as mp

from DLPT.transforms.patches import CenterCrop
from DLPT.utils.asserts import orientations, type_assert, one_hot
from DLPT.utils.mri import normalizeMri, get_slice
from DLPT.utils.conversions import int_to_onehot

HARP_CLASSES = ["cn", "mci", "ad"]
default_harp = os.path.join("/home", "diedre", "Dropbox", "bigdata", "harp")


class HARP(Dataset):
    '''
    This is not compatible with the masters HARP experiments dataset.
    New standalone HARP class that handles correct slice and volume selection.
    Pre-processed volumes and slices are supposed to be saved in processed and processed_slices in the deafult_harp path
    List of all volume IDs per classification class inside class.
    '''
    KEY_LIST = {'cn': ['029_S_4279', '009_S_0862', '032_S_0677', '094_S_4460', '029_S_4385', '133_S_0525', '020_S_1288',
                       '010_S_0067', '003_S_0931', '002_S_1280', '009_S_0842', '011_S_0021', '073_S_0089', '002_S_0559',
                       '127_S_0259', '023_S_0061', '005_S_0602', '007_S_4387', '002_S_0685', '018_S_0425', '011_S_0002',
                       '002_S_0295', '006_S_4449', '037_S_0303', '002_S_0413', '100_S_0047', '011_S_0005', '129_S_4369',
                       '003_S_0907', '100_S_0015', '127_S_0260', '123_S_0072', '002_S_1261', '123_S_0106', '002_S_4225',
                       '100_S_1286', '098_S_0172', '023_S_0031', '010_S_0419', '013_S_4731', '016_S_4121', '032_S_0479',
                       '013_S_1276', '011_S_0016'],
                'mci': ['123_S_0108', '013_S_0325', '136_S_0579', '002_S_1070', '003_S_0908', '002_S_0782', '136_S_0429',
                        '006_S_0322', '003_S_1074', '011_S_0241', '023_S_0030', '005_S_0448', '002_S_0729', '009_S_1030',
                        '123_S_0050', '131_S_0384', '003_S_1122', '013_S_1186', '127_S_0397', '023_S_0331', '007_S_0128',
                        '012_S_1292', '012_S_1321', '002_S_0954', '016_S_1092', '023_S_0604', '023_S_1247', '011_S_0856',
                        '010_S_0422', '100_S_0892', '123_S_0390', '094_S_1293', '016_S_0769', '005_S_0222', '131_S_1389',
                        '123_S_1300', '100_S_0995', '016_S_1138', '126_S_1340', '002_S_1155', '003_S_1057', '023_S_0376',
                        '127_S_0393', '100_S_0006', '029_S_1073', '007_S_0101'],
                'ad': ['067_S_1185', '003_S_4136', '123_S_0162', '009_S_1334', '003_S_4142', '005_S_1341', '006_S_4192',
                       '126_S_0784', '018_S_4696', '067_S_0812', '100_S_1062', '130_S_0956', '003_S_1059', '123_S_0091',
                       '023_S_0916', '013_S_0592', '016_S_0991', '127_S_0844', '031_S_1209', '023_S_0139', '020_S_0213',
                       '011_S_0010', '027_S_1081', '002_S_0938', '005_S_0221', '002_S_0816', '016_S_1263', '067_S_1253',
                       '023_S_1289', '127_S_0754', '098_S_0149', '011_S_0183', '123_S_0088', '019_S_4549', '027_S_1385',
                       '003_S_1257', '131_S_0691', '012_S_0689', '094_S_4089', '123_S_0094', '019_S_4252', '126_S_0606',
                       '130_S_4730', '082_S_1079', '007_S_1304']}

    def __init__(self, group, mode, transform=None, verbose=False, return_details=False, class_only=False,
                 return_onehot=False, orientation=None, e2d=False, sep_mode="holdout", splits=(0.7, 0.1, 0.2),
                 kfold=None, fold=None, target_only=False):

        '''
        Based on KEY_LIST splits files accordingly in train/val and test. Should be consistent with slices and volumes. Specially
        not mixing slices from the same individuals in different folds.
        '''
        super(HARP, self).__init__()
        assert mode in ["all", "train", "validation", "test"]
        assert group in ["all"] + HARP_CLASSES
        assert orientation in [None, "sagital", "coronal", "axial"]
        type_assert(bool, verbose, return_details, return_onehot, e2d, return_onehot)
        self.reconstruction_orientations = orientations
        self.fold = fold
        self.target_only = target_only
        self.mode = mode
        self.group = HARP_CLASSES if group == "all" else [group]
        self.return_details = return_details
        self.class_only = class_only
        self.return_onehot = return_onehot
        self.transform = transform
        self.keys = []
        self.verbose = verbose
        self.orientation = orientation
        self.e2d = e2d

        # Group selection
        for g in self.group:
            self.keys = self.keys + HARP.KEY_LIST[g]

        # Fold/mode Selection
        if self.mode != "all":
            self.keys = self.get_holdout_or_kfold_set(self.keys, mode, sep_mode=sep_mode, splits=splits, kfold=kfold, fold=fold)

        # Check balance
        balance = {"cn": 0, "mci": 0, "ad": 0}
        for key in self.keys:
            for group in balance:
                if key in HARP.KEY_LIST[group]:
                    balance[group] += 1

        logging.debug("IDs used:")
        logging.debug(self.keys)

        # Get slices from folders in keys
        if self.orientation is not None:
            self.slices = []
            for key in self.keys:
                self.slices = self.slices + glob.glob(add_path(default_harp, "processed_slices", key,
                                                      self.orientation[0] + "*.npz"))
            self.keys = self.slices

        final_len = len(self.keys)

        if self.verbose:
            logging.info("HARP args -> group: {}, mode: {}, fold: {}, transform: {}, verbose: {}, return_details: {}, "
                         "return_onehot: {}, volumetric lenght: {}, balance: {}".format(group, mode, fold, transform, verbose,
                                                                                        return_details, return_onehot, final_len,
                                                                                        balance))

    def __len__(self):
        '''
        Returns how many volumes/slices are in the dataset
        '''
        return len(self.keys)

    def __getitem__(self, i):
        '''
        Returns slice/volume according to parameters set in init
        '''
        key = self.keys[i]
        if self.verbose:
            logging.info("Subject: {}".format(key))

        if self.orientation is None:
            npz = np.load(add_path(default_harp, "processed", key + ".npz"))
            data = npz["vol"]
        else:
            # in slice mode, keys are already full paths
            npz = np.load(key)
            if self.e2d:
                center_data = npz["vol"]
                slice_number = int(os.path.basename(key).split('.')[0][1:])
                post_slice = add_path(os.path.dirname(key), self.orientation[0] + str(slice_number + 1) + ".npz")
                pre_slice = add_path(os.path.dirname(key), self.orientation[0] + str(slice_number - 1) + ".npz")

                if os.path.exists(post_slice):
                    post_data = np.load(post_slice)["vol"]
                else:
                    post_data = center_data

                if os.path.exists(pre_slice):
                    pre_data = np.load(pre_slice)["vol"]
                else:
                    pre_data = center_data

                data = np.zeros((3, center_data.shape[0], center_data.shape[1]), dtype=center_data.dtype)
                pre_shape, center_shape, post_shape = pre_data.shape, center_data.shape, post_data.shape

                if (pre_shape != post_shape or pre_shape != center_shape or center_shape != post_shape):
                    if self.verbose:
                        logging.info("Concatenating slices of different shapes")
                    cc = CenterCrop(*center_shape)
                    pre_data, post_data = cc(pre_data), cc(post_data)

                data[0] = pre_data
                data[1] = center_data
                data[2] = post_data
            else:
                data = npz["vol"]

        if self.return_onehot:
            target = npz["onehot_target"]
            assert one_hot(torch.from_numpy(target).unsqueeze(0))
        else:
            target = npz["class_target"]

        if self.transform is not None:
            data, target = self.transform(data, target)

        if self.return_details:
            label = None

            for k, v in HARP.KEY_LIST.items():
                if key in v:
                    label = k

            if label is None:
                raise RuntimeError("Label for key {} was not found...?".format(k))

            if self.class_only:
                if self.target_only:
                    return torch.ones(1), HARP_CLASSES.index(label)
                else:
                    return data, HARP_CLASSES.index(label)

            else:
                return data, (target, HARP_CLASSES.index(label))
        else:
            return data, target

    @staticmethod
    def process_rawvolumes():
        '''
        Populates processed folder npz
        '''
        for k, v in tqdm(HARP.KEY_LIST.items()):
            for harp_id in tqdm(v):
                vol_path = add_path(default_harp, "samples", k, harp_id + ".nii.gz")
                mask_path = add_path(default_harp, "masks", "all", harp_id + ".nii.gz")
                vol = nib.load(vol_path).get_fdata()
                hip = nib.load(mask_path).get_fdata()
                norm_vol = normalizeMri(vol.astype(np.float32))
                norm_hip = hip.astype(np.bool).astype(np.float32)
                onehot_hip = int_to_onehot(norm_hip)
                assert onehot_hip.shape[0] == 2
                np.savez_compressed(add_path(default_harp, "processed", harp_id), vol=norm_vol, class_target=norm_hip,
                                    onehot_target=onehot_hip)

    @staticmethod
    def process_slices():
        '''
        Populates processed slices npz
        '''
        db = HARP("all", "all")
        onehot_db = HARP("all", "all", return_onehot=True, return_details=True)

        for i in tqdm(range(len(db))):
            data, class_target = db[i]
            _, onehot_target, label, key = onehot_db[i]
            os.makedirs(add_path(default_harp, "processed_slices", key), exist_ok=True)
            logging.info(data.shape, class_target.shape, onehot_target.shape)
            for orientation in tqdm(range(3)):
                for slice_index in tqdm(range(data.shape[orientation])):
                    class_slice = get_slice(class_target, slice_index, orientations[orientation], rotate=90)
                    if class_slice.sum() > 0:
                        _slice = get_slice(data, slice_index, orientations[orientation], rotate=90)
                        onehot_slice = get_slice(onehot_target, slice_index, orientations[orientation], rotate=90)
                        np.savez_compressed(add_path(default_harp, "processed_slices", key,
                                                     orientations[orientation][0] + str(slice_index)) + ".npz", vol=_slice,
                                            class_target=class_slice, onehot_target=onehot_slice)


def test_harp(display=False, long_test=False):
    import random
    from collections import Counter
    from DLPT.visualization import itksnap

    ncpu = mp.cpu_count()

    if display:
        itkm = itksnap.ITKManager()
        itkm.itk_alloc_max = 5

    # Balacing Test
    for mode in ["train", "validation", "test"]:
        test_dataset = HARP(group="all", mode="test", verbose=False, return_details=True, class_only=True, target_only=True)
        tgts = test_dataset.get_all_tgts()
        count = Counter(tgts)
        logging.info(f"{mode} tgts: {count}")

    # Load test
    test_dataset = HARP(group="all", mode="all", verbose=False, return_details=True)
    dataloader = test_dataset.get_dataloader(1, True, ncpu)
    if long_test:
        for batch in tqdm(dataloader, total=len(dataloader)):
            vol, (tgt, label) = batch
            assert tgt.sum() > 0 and tgt.max() <= 1 and tgt.min() >= 1
        # Fold test
        for fold in range(1, 6):
            test_dataset = HARP(group="all", mode="test", verbose=False, return_details=True, class_only=True, sep_mode="kfold",
                                kfold=5, fold=fold, target_only=True)
            logging.info("Fold: {}, tgts: {}".format(fold, test_dataset.get_all_tgts()))
    else:
        vol, (tgt, label) = random.choice(test_dataset)
        logging.info(f"Random Label: {label}")
        if display:
            itkm.alloc((vol, tgt))
