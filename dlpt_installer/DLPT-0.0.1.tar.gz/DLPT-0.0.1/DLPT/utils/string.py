'''
String manipulation functions
'''


def concat_with_space(*args) -> str:
    '''
    Concatenates list of string args with spaces.
    Looks better than using ' '.join([a, b, ...])
    '''
    return ' '.join(args)
