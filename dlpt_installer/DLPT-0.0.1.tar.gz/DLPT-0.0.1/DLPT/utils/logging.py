'''
Functions related to logging
'''
import logging


def init_logging(debug):
    '''
    Configures logging
    '''
    import sys
    sys.path.append("/home/diedre/git/diedre_phd/")  # workaround until DLPT becomes a pip package
    sys.path.append("/home/diedre/git/diedre_phd/DLPT")  # workaround until DLPT becomes a pip package

    FORMAT = '%(asctime)s %(levelname)s: %(message)s'
    logging.basicConfig(level=logging.DEBUG if debug else logging.INFO,  format=FORMAT)
    logging.info("Logging initialized with debug={}".format(debug))
