'''
Some utilities functions related to handling MRI volumes
'''
import copy
import numpy as np
import cv2 as cv
from skimage.transform import rotate

from DLPT.utils.asserts import orientations


def myrotate(inpt, d, order=0):
    '''
    Simplifies rotation calls for 2D images
    '''
    if d == 0:
        return inpt
    else:
        return rotate(inpt, d, resize=True, order=order)


def center_crop_volume(voxels, desired_shape):
    '''
    Simple center crop for a given volume.
    Use transforms.patches.CenterCrop for more complicated cases.
    '''
    assert len(voxels.shape) == 3, "center_crop_volume only supports 3D arrays"
    z, y, x = voxels.shape

    startz = z//2-(desired_shape[0]//2)
    starty = y//2-(desired_shape[1]//2)
    startx = x//2-(desired_shape[2]//2)

    return voxels[startz:startz+80, starty:starty+80, startx:startx+80]


def split_l_r(volume, sagittal_axis=0):
    '''
    This assumes the brain is centered
    '''

    sagittal_len = volume.shape[sagittal_axis]
    internalv_l, internalv_r = copy.deepcopy(volume), copy.deepcopy(volume)

    if sagittal_axis == 0:
        internalv_r[:sagittal_len//2] = 0
        internalv_l[sagittal_len//2:] = 0
    elif sagittal_axis == 1:
        internalv_r[:, :sagittal_len//2] = 0
        internalv_l[:, sagittal_len//2:] = 0
    elif sagittal_axis == 2:
        internalv_r[:, :, :sagittal_len//2] = 0
        internalv_l[:, :, sagittal_len//2:] = 0
    else:
        raise ValueError("Invalid sagittal axis")

    return {"left": internalv_l, "right": internalv_r}


def normalizeMri(data):
    '''
    Normalizes float content on MRI samples to 0-1, using min-max normalization

    data: input 3D numpy data do be normalized
    returns: normalized 3D numpy data
    '''
    img = np.zeros((data.shape), dtype=data.dtype)
    cv.normalize(data, img, alpha=1.0, beta=0.0, norm_type=cv.NORM_MINMAX)
    return img


def get_slice(vol, i, orientation, rotate=90, orientations=orientations):
    ndim = vol.ndim
    if orientation not in orientations:
        raise ValueError("Unsupported orientation {} should be one of {}".format(orientation, orientations))
    ix = orientations.index(orientation)
    if ndim == 3:
        if ix == 0:
            return myrotate(vol[i, :, :], rotate)
        elif ix == 1:
            return myrotate(vol[:, i, :], rotate)
        elif ix == 2:
            return myrotate(vol[:, :, i], rotate)
    elif ndim == 4:
        if ix == 0:
            post_rotation_shape = myrotate(np.zeros(vol[0, 0, :, :].shape, dtype=np.uint8), rotate).shape
            ret_slice = np.zeros((vol.shape[0], post_rotation_shape[0], post_rotation_shape[1]), dtype=vol.dtype)
            for dim in range(vol.shape[0]):
                ret_slice[dim] = myrotate(vol[dim, i, :, :], rotate)
        elif ix == 1:
            post_rotation_shape = myrotate(np.zeros(vol[0, :, 0, :].shape, dtype=np.uint8), rotate).shape
            ret_slice = np.zeros((vol.shape[0], post_rotation_shape[0], post_rotation_shape[1]), dtype=vol.dtype)
            for dim in range(vol.shape[0]):
                ret_slice[dim] = myrotate(vol[dim, :, i, :], rotate)
        elif ix == 2:
            post_rotation_shape = myrotate(np.zeros(vol[0, :, :, 0].shape, dtype=np.uint8), rotate).shape
            ret_slice = np.zeros((vol.shape[0], post_rotation_shape[0], post_rotation_shape[1]), dtype=vol.dtype)
            for dim in range(vol.shape[0]):
                ret_slice[dim] = myrotate(vol[dim, :, :, i], rotate)
        return ret_slice
    else:
        raise ValueError("ndims for slice acquistion not supported")
