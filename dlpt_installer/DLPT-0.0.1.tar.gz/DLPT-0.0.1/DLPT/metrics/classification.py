'''
Good old accuracy
'''
from torch import Tensor
from sklearn.metrics import f1_score, accuracy_score, precision_score, recall_score

from DLPT.metrics import Metric


class Accuracy(Metric):
    def __init__(self):
        self.lower_is_best = False
        self.name = "Accuracy"

    def __call__(self, outputs: Tensor, target: Tensor) -> float:
        classes = outputs.argmax(dim=1).long()
        assert classes.shape == target.shape
        return accuracy_score(target.detach().cpu().numpy(), classes.detach().cpu().numpy())


class WeightedF1Score(Metric):
    def __init__(self):
        self.lower_is_best = False
        self.name = "WeightedF1Score"

    def __call__(self, outputs: Tensor, target: Tensor) -> float:
        classes = outputs.argmax(dim=1).long()
        assert classes.shape == target.shape
        return f1_score(target.detach().cpu().numpy(), classes.detach().cpu().numpy(), average="weighted")


class WeightedPrecision(Metric):
    def __init__(self):
        self.lower_is_best = False
        self.name = "WeightedPrecision"

    def __call__(self, outputs: Tensor, target: Tensor) -> float:
        assert outputs.shape == target.shape
        return precision_score(target.detach().cpu().view(-1).numpy(), outputs.detach().cpu().view(-1).numpy(),
                               average="weighted")


class WeightedRecall(Metric):
    def __init__(self):
        self.lower_is_best = False
        self.name = "WeightedRecall"

    def __call__(self, outputs: Tensor, target: Tensor) -> float:
        assert outputs.shape == target.shape
        return recall_score(target.detach().cpu().view(-1).numpy(), outputs.detach().cpu().view(-1).numpy(), average="weighted")
