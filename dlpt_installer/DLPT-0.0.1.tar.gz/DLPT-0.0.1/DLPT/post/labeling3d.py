'''
Post-processing interfacing with ia870 toolbox (https://github.com/MICLab-Unicamp/ia870)
'''

import numpy as np
from PIL import Image
from ia870 import ialabel
import cv2 as cv
import time


def get_largest_components(volume, mask_ths=0.5, ncomponents=2, debug=False):
    '''
    Returns 2 or 1 largest components, input should be numpy in cpu
    '''
    begin = time.time()

    volume = volume > mask_ths

    if volume.astype(np.int).sum() == 0:
        return volume.astype(np.float32)

    labels = ialabel(volume, np.ones((3, 3, 3), dtype=bool))

    bincount = np.bincount(labels.flat)
    if debug:
        print("label count: {}".format(bincount))

    # Increasing sort (0, 1, 2 ,3...)
    sorted_count = np.sort(bincount)

    # Gets two labels in bincount with more area, excluding the object with higher area (background)
    largest_components = {}

    upper_limit = 4
    if len(bincount) == 2:
        upper_limit = 3

    for i in range(2, upper_limit):
        label = np.where(bincount == sorted_count[-i])[0][0]
        largest_components[str(label)] = sorted_count[-i]

    if debug:
        print("two highest labels excluding highest {}".format(largest_components))
        print("largest components processing time: {}s".format(time.time() - begin))

    highest_labels = np.asarray(list(largest_components.keys()), dtype=np.int64)
    if debug:
        print("Largest object labels: {}".format(highest_labels))

    # print(labels.max())
    # print(labels.min())
    # print(labels.dtype)
    hlabel_len = len(highest_labels)
    if hlabel_len >= 2:
        return (np.ma.masked_not_equal(labels, highest_labels[0]).filled(0) + np.ma.masked_not_equal(labels,
                highest_labels[1]).filled(0)).astype(np.bool).astype(np.float32)
    else:
        return np.ma.masked_not_equal(labels, highest_labels[0]).filled(0).astype(np.bool).astype(np.float32)
