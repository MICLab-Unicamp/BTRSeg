'''
From Generalised dice overlap as a deep learning loss function for highly unbalanced segmentations
'''
from typing import List

import torch
from torch import Tensor
from torch import einsum

from DLPT.utils.asserts import simplex


class GeneralizedDice():
    '''
    Code from Boundary loss for highly unbalanced segmentation
    '''
    def __init__(self, **kwargs):
        # Self.idc is used to filter out some classes of the target mask. Use fancy indexing
        self.name = "GDL"
        self.loss = kwargs["loss"]
        self.lower_is_best = self.loss
        self.idc: List[int] = kwargs["idc"]

        self.dim = kwargs["dim"] if "dim" in kwargs else 2
        print(f"Initialized {self.__class__.__name__} with {kwargs}")

    def __call__(self, probs: Tensor, target: Tensor) -> Tensor:
        assert simplex(probs) and simplex(target)

        pc = probs[:, self.idc, ...].type(torch.float32)
        tc = target[:, self.idc, ...].type(torch.float32)

        if self.dim == 2:
            w: Tensor = 1 / ((einsum("bcwh->bc", tc).type(torch.float32) + 1e-10) ** 2)
            intersection: Tensor = w * einsum("bcwh,bcwh->bc", pc, tc)
            union: Tensor = w * (einsum("bcwh->bc", pc) + einsum("bcwh->bc", tc))

            divided: Tensor = 2 * (einsum("bc->b", intersection) + 1e-10) / (einsum("bc->b", union) + 1e-10)
        elif self.dim == 3:
            w: Tensor = 1 / ((einsum("bcdwh->bc", tc).type(torch.float32) + 1e-10) ** 2)
            intersection: Tensor = w * einsum("bcdwh,bcdwh->bc", pc, tc)
            union: Tensor = w * (einsum("bcdwh->bc", pc) + einsum("bcdwh->bc", tc))

            divided: Tensor = 2 * (einsum("bc->b", intersection) + 1e-10) / (einsum("bc->b", union) + 1e-10)
        else:
            raise ValueError("Only supporting 2D or 3D")

        if self.loss:
            divided = 1 - divided

        loss = divided.mean()

        return loss
