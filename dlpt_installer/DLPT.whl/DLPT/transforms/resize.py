from scipy.ndimage import zoom
import random
import numpy as np
import logging
from DLPT.transforms import Transform


class Resize(Transform):
    '''
    Resize sample and target if aplicable
    '''
    def __init__(self, x, y, z=None, segmentation=True):
        '''
        size: (width, height)
        '''
        self.x = x
        self.y = y
        self.z = z
        if z is not None:
            self.volumetric = True
        else:
            self.volumetric = False
        self.segmentation = segmentation

    def __call__(self, image, target):
        '''
        Image and mask should be numpy arrays
        '''
        if self.volumetric:
            ix, iy, iz = image.shape
            zimage = zoom(image, (self.x/ix, self.y/iy, self.z/iz), order=3)
            if self.segmentation:
                ztarget = zoom(target, (self.x/ix, self.y/iy, self.z/iz), order=0)
            else:
                ztarget = target
        else:
            ix, iy = image.shape
            zimage = zoom(image, (self.x/ix, self.y/iy), order=3)
            if self.segmentation:
                ztarget = zoom(target, (self.x/ix, self.y/iy))
            else:
                ztarget = target

        return zimage, ztarget

    def __str__(self):
        return "Resize: size {} {} {}, volumetric {}, segmentation {}".format(self.x, self.y, self.z if self.volumetric else '',
                                                                              self.volumetric, self.segmentation)


class Random4DResize(Transform):
    '''
    Resize sample for a random factor
    Works only in 4D volumes
    '''
    def __init__(self, p=0.5, factor=0.1, reset_seed=True):
        '''
        p change to resize a 4D volume by a factor in [1-factor, 1+factor]
        '''
        self.factor = factor
        self.p = p
        self.reset_seed = reset_seed

    def __call__(self, image, target):
        '''
        Image and mask should be numpy 4D array
        '''
        if self.reset_seed:
            random.seed()
        if random.random() < self.p:
            factor = 1 + ((random.random() - 0.5)*2*self.factor)
            logging.debug(f"Applying random4dresize {factor}")
            image = np.stack([zoom(channel, factor) for channel in image])
        else:
            logging.debug("Not applying random4dresize")

        return image, target

    def __str__(self):
        return f"Random4DResize: factor: {self.factor}"
