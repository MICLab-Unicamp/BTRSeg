'''
Uses external program ITK_Snap to display stuff
'''
import datetime
import subprocess
import logging
import time
import multiprocessing as mp

import numpy as np
import cv2 as cv

from utils.cache import cache_a_volume, clear_cache
from visualization.cvshow import image_print


class ITKManager():
    '''
    Global class managing ITK spawns, using multiprocessing.
    '''
    def __init__(self, max_windows=2):
        '''
        max_windows: maximum instantiations of itksnap allowed at the same time
        '''
        self.itk_alloc_max = max_windows
        self.manager = mp.Manager()
        self.currently_alloced = self.manager.Value('i', 0)
        self.sig_term = self.manager.Value('i', 0)
        self.ps = []

    def increase_max(self):
        self.itk_alloc_max += 1

    def decrease_max(self):
        self.itk_alloc_max -= 1

    def alloc(self, args):
        '''
        args: tuple containing volumes to display in vol, mask, reference order
        '''
        assert isinstance(args, tuple)
        while not self.available():
            cv.imshow("ITK-Manager Status", image_print(np.zeros((200, 1200)), str(self) + " Press ESC to quit."))
            key = cv.waitKey(1)
            if key == 27:
                return 1

        self.currently_alloced.value = self.currently_alloced.value + 1

        p = mp.Process(target=spawn_itk, args=(self,) + args)
        p.start()
        self.ps.append(p)

    def dealloc(self):
        self.currently_alloced.value = self.currently_alloced.value - 1

    def available(self):
        return self.currently_alloced.value < self.itk_alloc_max

    def terminate(self):
        self.sig_term.value = 1

        for p in self.ps:
            p.join()

    def __str__(self):
        return "{}/{} ITKs running.".format(self.currently_alloced.value, self.itk_alloc_max)


def spawn_itk(itk_manager, vol, mask=None, ref=None, clear=True):
    '''
    Only use this in the context of ITKManager's alloc
    Calls itksnap via its cli
    TODO have a better reference to itksnap than a full folder
    '''
    try:
        vol_id = "vol" + str(datetime.datetime.now())
        mask_id = "mask" + str(datetime.datetime.now())
        ref_id = "ref" + str(datetime.datetime.now())
        volpath = cache_a_volume(vol, vol_id)

        if mask is None and ref is None:
            status = subprocess.Popen(["/home/diedre/git/diedre/masters/bin/itksnap3.6/bin/itksnap",
                                       "-g", volpath], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif ref is None:
            maskpath = cache_a_volume(mask, mask_id)
            status = subprocess.Popen(["/home/diedre/git/diedre/masters/bin/itksnap3.6/bin/itksnap",
                                       "-g", volpath,
                                       "-s", maskpath], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            maskpath = cache_a_volume(mask, mask_id)
            refpath = cache_a_volume(ref, ref_id)
            status = subprocess.Popen(["/home/diedre/git/diedre/masters/bin/itksnap3.6/bin/itksnap",
                                       "-g", volpath, "-o", refpath,
                                       "-s", maskpath], stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        while status.poll() is None and not itk_manager.sig_term.value:
            time.sleep(1)

        if status.poll() is None:
            print("Closing lingering ITK windows...")
            status.terminate()

        if clear:
            clear_cache(vol_id, mask_id, ref_id)

        itk_manager.dealloc()
    except FileNotFoundError:
        logging.error("Error trying to use itksnap. Do you have it in the bin folder?", exc_info=True)
    except Exception:
        logging.error("Internal error in ITK Spawner.", exc_info=True)
