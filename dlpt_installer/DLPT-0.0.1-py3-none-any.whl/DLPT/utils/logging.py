'''
Functions related to logging
'''
import logging


def init_logging(debug):
    '''
    Configures logging
    '''
    FORMAT = '%(asctime)s %(levelname)s: %(message)s'
    logging.basicConfig(level=logging.DEBUG if debug else logging.INFO, format=FORMAT)
    logging.info("Logging initialized with debug={}".format(debug))
