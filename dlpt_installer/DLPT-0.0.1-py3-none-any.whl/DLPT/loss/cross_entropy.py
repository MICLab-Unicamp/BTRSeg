'''
Wraps Cross Entropy Loss
'''
import torch.nn as nn
from torch import Tensor
from loss import Loss


class CrossEntropyLoss(Loss):
    '''
    Simple wrapper
    '''
    def __init__(self, metric=False):
        self.name = "Cross Entropy Loss"
        super(CrossEntropyLoss, self).__init__()
        self.loss = nn.CrossEntropyLoss()
        self.metric = metric

    def __call__(self, outputs: Tensor, target: Tensor) -> Tensor:
        if self.metric:
            return self.loss(outputs, target).item()
        else:
            return self.loss(outputs, target)
