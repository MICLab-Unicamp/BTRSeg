'''
My adaptation of Assessing Knee OA Severity with CNN attention-based end-to-end architectures
(https://arxiv.org/pdf/1908.08856.pdf) to a 3D architecture
'''
import numpy as np
import torch
from torch import nn
from visualization.multiview import multi_channel_zoom


class AttentionModule(nn.Module):
    def __init__(self, nin: int, nout: int, survival_regression=False):
        '''
        nin: number of channels of expected input
        nout: number of channels of output

        Attention will be stored in self.att after prediction
        '''
        super(AttentionModule, self).__init__()
        self.survival_regression = survival_regression
        self.first_conv = nn.Conv3d(nin, 16, kernel_size=1, stride=1, padding=0, bias=True)
        self.second_conv = nn.Conv3d(16, 4, kernel_size=1, stride=1, padding=0, bias=True)
        self.third_conv = nn.Conv3d(4, 1, kernel_size=1, stride=1, padding=0, bias=True)
        self.gap = nn.AdaptiveAvgPool3d(1)
        self.fc = nn.Linear(nin + 2*survival_regression, nout)

    def forward(self, x):
        if self.survival_regression:
            x, tumor_type, age = x

        y = self.first_conv(x).relu()
        y = self.second_conv(y).relu()
        self.att = self.third_conv(y).sigmoid()
        y = self.att*x

        # Global Average Pooling features
        y = self.gap(y).view(y.shape[0], -1)

        if self.survival_regression:
            y = self.fc(torch.cat((y, tumor_type, age), dim=-1))
        else:
            y = self.fc(y)

        return y


class ConvBlock3D(nn.Module):
    def __init__(self, nin, nout):
        '''
        nin: number of channels of expected input
        nout: number of channels of output
        '''
        super(ConvBlock3D, self).__init__()
        self.first_conv = nn.Conv3d(nin, nout, kernel_size=3, stride=1, padding=1, bias=True)
        self.first_bn = nn.GroupNorm(8, nout)
        self.second_conv = nn.Conv3d(nout, nout, kernel_size=3, stride=2, padding=1, bias=True)
        self.second_bn = nn.GroupNorm(8, nout)

    def forward(self, x):
        x = self.first_conv(x).relu()
        x = self.first_bn(x)

        x = self.second_conv(x).relu()
        x = self.second_bn(x)

        return x


class CNN3DAtt(nn.Module):
    '''
    For classification or regression using attention.
    '''
    def __init__(self, nin, nout, channel_factor=1, limit_output=None, survival_regression=False):
        '''
        nin: number of channels of expected input
        nout: number of channels of output
        return_att: wether to return attention maps
        channel_factor: factor to increase or decrease network size (adjust memory consumption)
        limit_output: limits and uses sigmoid regression output if not None. If limit output None, consider this a
        classification network. Defaults to BRATS survival range.
        '''
        super(CNN3DAtt, self).__init__()
        self.limit_output = limit_output
        self.survival_regression = survival_regression
        self.name = "CNN3DAtt"
        self.first_block = ConvBlock3D(nin, int(16*channel_factor))
        self.second_block = ConvBlock3D(int(16*channel_factor), int(32*channel_factor))
        self.third_block = ConvBlock3D(int(32*channel_factor), int(64*channel_factor))
        self.att0 = AttentionModule(int(64*channel_factor), nout, survival_regression=survival_regression)
        self.fourth_block = ConvBlock3D(int(64*channel_factor), int(128*channel_factor))
        self.att1 = AttentionModule(int(128*channel_factor), nout, survival_regression=survival_regression)
        self.fifth_block = ConvBlock3D(int(128*channel_factor), int(128*channel_factor))
        self.att2 = AttentionModule(int(128*channel_factor), nout, survival_regression=survival_regression)

        self.fc = nn.Linear(3*nout + 2*survival_regression, nout)

    def summary(self):
        print(str(self))

    def return_atts(self, verbose=True):
        '''
        Returns attentions interpolated to input size (ndarray)
        '''
        # Squeeze channel
        atts = [self.att0.att.squeeze(1), self.att1.att.squeeze(1), self.att2.att.squeeze(1)]

        zoomed_atts = []
        for att in atts:
            ishape = np.array(self.input_shape)
            ashape = np.array(att.shape[1:])
            assert len(ishape) == len(ashape)
            zoom_factors = (ishape/ashape).tolist()
            zoomed_atts.append(multi_channel_zoom(att.detach().cpu().numpy(), zoom_factors=zoom_factors, order=5, C=4,
                                                  tqdm_on=verbose))

        return zoomed_atts

    def limit(self, x):
        if self.limit_output is None:
            return x
        else:
            return self.limit_output[0] + x.sigmoid()*(self.limit_output[1] - self.limit_output[0])

    def forward(self, x):
        if self.survival_regression:
            x, tumor_type, age = x

        self.input_shape = (x.shape[-3], x.shape[-2], x.shape[-1])
        x = self.first_block(x)
        x = self.second_block(x)
        x = self.third_block(x)

        feat0 = self.att0((x, tumor_type, age)) if self.survival_regression else self.att0(x)

        x = self.fourth_block(x)
        feat1 = self.att1((x, tumor_type, age)) if self.survival_regression else self.att1(x)

        x = self.fifth_block(x)
        feat2 = self.att2((x, tumor_type, age)) if self.survival_regression else self.att2(x)

        feat_mean = torch.cat((self.limit(feat0),
                               self.limit(feat1),
                               self.limit(feat2)), dim=-1).mean(dim=-1)  # concatenate and reduce by mean over the last dimension

        return feat_mean


def test_cnn3d_att(display=False, long_test=False):
    import os
    import logging

    test_volume = torch.randn(2, 4, 64, 64, 64)

    # 1 output for regression

    cnn3datt = CNN3DAtt(4, 1)
    cnn3datt.summary()
    test_out = cnn3datt(test_volume)
    test_out = test_out.detach().cpu()
    logging.info(f"Output: {test_out[0]}")

    atts = cnn3datt.return_atts(verbose=True)
    for i, att in enumerate(atts):
        logging.info(f'att {i}: {att.shape}')

    logging.info("Saving test..")
    path = os.path.join("cache", "cnn3d_atttest.pt")
    torch.save(cnn3datt.state_dict(), path)
    _ = CNN3DAtt(4, 1).load_state_dict(torch.load(path))
