'''
This package implements many methods, ideally each per module.
'''
