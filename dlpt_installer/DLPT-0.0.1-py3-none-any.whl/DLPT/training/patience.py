'''
Implements patience strategies
'''
import logging
from utils.asserts import assert_mode
from training.results import Results


class DefaultPatience():
    '''
    Simple patience computing.
    Increments counter everytime a value is not the best among its history, given by a results object.
    Returns False and resets counter when count passes a given threshold.
    If max_patience is 0, patience is never broken and __call__ always returns True (infinite patience).
    '''
    def __init__(self, max_patience: int, lower_is_best=False, mode="validation", reference="Metric"):
        assert_mode(mode)

        self.lower_is_best = lower_is_best
        self.max_patience = max_patience
        self.patience_count = 0
        self.mode = mode
        self.reference = reference

        logging.debug("DefaultPatience initialized with: max_patience: {}, best_is_lower: {}, mode: {}, "
                      "reference: {}.".format(max_patience, lower_is_best, mode, reference))

    def __call__(self, results: Results, current: float) -> bool:
        '''
        Returns if given current value, to a "name" metric/loss is the best one yet
        '''
        if results.check_best_yet(current, mode=self.mode, name=self.reference, lower_is_best=self.lower_is_best):
            self.patience_count = 0
        else:
            self.patience_count += 1

        logging.info("Patience Level: {}/{}".format(self.patience_count, self.max_patience))

        if self.patience_count >= self.max_patience:
            logging.info("Patience over limit of {}.".format(self.max_patience))
            self.patience_count = 0
            return False
        else:
            return True


def patience_test():
    '''
    Tests the patience classes in many possible situations using simulated results.
    Patient breaking moment should follow expected vectors for the test to pass
    '''
    from training.results import Results

    logging.info("Testing patience module.\n")

    test_values = [0.30, 0.80, 0.5, 0.1, 0.99, 0.30, 0.80, 0.5, 0.1, 0.99]
    expected_results = {"lower_is_best": [True, True, True, True, True, True, True, True, False, True],
                        "higher_is_best": [True, True, True, True, True, True, True, True, True, False]}

    for mode in ["train", "validation"]:
        for reference in ["Loss", "Metric"]:
            for lower_is_best in [True, False]:
                default_patience = DefaultPatience(5, lower_is_best=lower_is_best, mode=mode, reference=reference)
                results = Results("Patience Test Results", "Loss", ["Metric"])
                still_patient = True
                for i, tvalue in enumerate(test_values):
                    value = {"Loss": {"train": tvalue,
                                      "validation": tvalue},
                             "Metric": {"train": tvalue,
                                        "validation": tvalue}}

                    still_patient = default_patience(results, value[reference][mode])
                    assert still_patient == expected_results["lower_is_best" if lower_is_best else "higher_is_best"][i]

                    results.append_to("train", "Loss", value["Loss"]["train"])
                    results.append_to("train", "Metric", value["Metric"]["train"])
                    results.append_to("validation", "Loss", value["Loss"]["validation"])
                    results.append_to("validation", "Metric", value["Metric"]["validation"])

    logging.info("Patience test completed without errors.\n")
