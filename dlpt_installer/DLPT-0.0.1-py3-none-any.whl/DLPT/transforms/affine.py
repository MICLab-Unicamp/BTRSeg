'''
Transformations related to the affine transform (rotation + scale)
'''
import random

import numpy as np
from skimage.transform import rotate

from transforms.resize import Resize
from transforms.patches import CenterCrop
from transforms import Transform


class RandomAffine(Transform):
    '''
    Randomly applies scale -> rotation to simulate different data source
    WARNING: Input has to have even shape, will be fixed soon
    TODO: Volumetric support
    '''
    LESS = -1
    EQUAL = 0
    MORE = 1

    def __init__(self, p=0.2, rotate=20, scale=(0.8, 1.2), fillmode='constant', volumetric=False, debug=False, reset_seed=True):
        self.p = p
        self.rotate = rotate
        self.scale = scale
        self.fmode = fillmode
        self.volumetric = volumetric
        self.debug = debug
        self.reset_seed = reset_seed

    def __call__(self, image, mask):
        debug = self.debug
        if self.reset_seed:
            random.seed()
        if random.random() < self.p:
            # Save original size for final center crop
            original_size = np.array(image.shape)

            im_ndim = image.ndim
            ma_ndim = mask.ndim

            if im_ndim > 2:
                original_size = np.array((original_size[1], original_size[2]))

            self.center_croper = CenterCrop(original_size[1], original_size[0])
            if debug:
                print("im {} mask {}".format(image.shape, mask.shape))
                print("Original size {}".format(original_size))
                print("IMDIM {}".format(im_ndim))
                print("MASKDIM {}".format(ma_ndim))
            # Pick a scale factor
            scale = random.uniform(self.scale[0], self.scale[1])

            # Target scale size
            scale_size = (scale*original_size).astype(np.int)

            # If odd, add + 1 for simplicity of padding later
            if scale_size[0] % 2:
                scale_size += 1

            # Apply scale
            self.resizer = Resize(scale_size[1], scale_size[0])
            if debug:
                print("pre resize mask {}")

            image, mask = self.resizer(image, mask)

            if debug:
                print("post resize mask {}")
                print("After resize im{}".format(image.shape))

            # Apply rotation
            ang = 2*(random.random() - 0.5)*self.rotate
            if debug:
                print("Rotating by {}".format(ang))
            if im_ndim > 2:
                for i in range(image.shape[0]):
                    image[i] = rotate(image[i], ang, preserve_range=True, mode=self.fmode, order=3)
            else:
                image = rotate(image, ang, preserve_range=True, mode=self.fmode, order=3)

            if ma_ndim > 2:
                for i in range(mask.shape[0]):
                    mask[i] = rotate(mask[i], ang, preserve_range=True, mode=self.fmode, order=0)
            else:
                mask = rotate(mask, ang, preserve_range=True, mode=self.fmode, order=0)

            if debug:
                print("After rot shape {}".format(image.shape))

            # Go back to original size
            shape_diff, (rowdiff, coldiff) = self.compare_shapes(image.shape, original_size)
            if shape_diff == self.LESS:
                if im_ndim > 2:
                    buffer = np.zeros((image.shape[0], original_size[0], original_size[1]), dtype=image.dtype)
                    for i in range(image.shape[0]):
                        buffer[i] = np.pad(image[i], (rowdiff//2, coldiff//2), mode=self.fmode)
                    image = buffer
                else:
                    image = np.pad(image, (rowdiff//2, coldiff//2), mode=self.fmode)

                if ma_ndim > 2:
                    buffer = np.zeros((mask.shape[0], original_size[0], original_size[1]), dtype=mask.dtype)
                    for i in range(mask.shape[0]):
                        buffer[i] = np.pad(mask[i], (rowdiff//2, coldiff//2), mode=self.fmode)
                    mask = buffer
                else:
                    if debug:
                        print("padding mask lul {} {}".format(rowdiff, coldiff))
                    mask = np.pad(mask, (rowdiff//2, coldiff//2), mode=self.fmode)

            elif shape_diff == self.EQUAL:
                pass
            elif shape_diff == self.MORE:
                image, mask = self.center_croper(image, mask)

            '''if e2d:
                cv.imshow("image", image[1])
            else:
                cv.imshow("image", image)
            cv.imshow("mask", mask)
            if cv.waitKey(0) == 27:
                quit()'''

            if debug:
                print("Final shapes: {}, {}".format(image.shape, mask.shape))

        return image, mask

    def __str__(self):
        return "RandomAffine: p {}, rotate {}, scale {}, fmode {}, volumetric {}".format(self.p, self.rotate, self.scale,
                                                                                         self.fmode, self.volumetric)

    def compare_shapes(self, shape1, refshape):
        '''
        shape1 > refshape = 1
        shape1 == refshape = 0
        shape1 < refshape = -1
        '''
        add = 0
        if len(shape1) == 3:
            # Add 1 to first shape if E2D
            add = 1

        rowdiff = refshape[0] - shape1[0 + add]
        coldiff = refshape[1] - shape1[1 + add]

        if shape1[0 + add] > refshape[0] and shape1[1 + add] > refshape[1]:
            return self.MORE, (rowdiff, coldiff)
        elif shape1[0 + add] == refshape[0] and shape1[1 + add] == refshape[1]:
            return self.EQUAL, (rowdiff, coldiff)
        elif shape1[0 + add] < refshape[0] and shape1[1 + add] < refshape[1]:
            return self.LESS, (rowdiff, coldiff)
        else:
            raise RuntimeError("Difference in shapes in RandomAffine not supported {} {}".format(shape1, refshape))
