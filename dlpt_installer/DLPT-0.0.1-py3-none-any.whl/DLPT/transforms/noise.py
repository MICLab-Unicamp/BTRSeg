'''
Transforming data through noise
'''
import random

import numpy as np

from transforms import Transform


class RandomGaussianNoise(Transform):
    '''
    Randomly adds gaussian or poison noise
    '''
    def __init__(self, noise="gaussian", p=0.2, var=0.0002, mean=0, reset_seed=True):
        self.p = p
        self.var = var
        self.mean = mean
        self.sigma = var**0.5
        self.noise = noise
        self.reset_seed = reset_seed
        supported_noises = ["gaussian", "poisson"]
        assert noise in supported_noises, "unsupported noise {} in Noisify, should be {}".format(noise, supported_noises)

    def __call__(self, image, mask):
        if self.reset_seed:
            random.seed()
        if random.random() < self.p:
            if self.noise == "gaussian":
                shape = image.shape
                gauss = np.random.normal(self.mean, self.sigma, shape)
                gauss = gauss.reshape(*shape)
                inoisy = image + gauss
            elif self.noise == "poisson":
                noise_mask = np.random.poisson(image)
                inoisy = image + noise_mask
            return inoisy, mask
        else:
            return image, mask

    def __str__(self):
        return "Noisify: noise {}, p {}, var {}, mean {}, sigma {}".format(self.noise, self.p, self.var, self.mean, self.sigma)
