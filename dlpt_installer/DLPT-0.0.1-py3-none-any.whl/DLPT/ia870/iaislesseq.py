# -*- encoding: utf-8 -*-
# Module iaislesseq

from numpy import *

def iaislesseq(f1, f2, MSG=None):


    bool = min(ravel(f1<=f2))


    return bool

