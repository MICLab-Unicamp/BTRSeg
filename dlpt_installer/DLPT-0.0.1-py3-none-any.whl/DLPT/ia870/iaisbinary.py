# -*- encoding: utf-8 -*-
# Module iaisbinary

from numpy import *

def iaisbinary(f):

  return f.dtype == bool

